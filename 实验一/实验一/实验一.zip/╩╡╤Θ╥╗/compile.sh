gcc -c src.c 
gcc src.o -o src.out

./src.out $@
